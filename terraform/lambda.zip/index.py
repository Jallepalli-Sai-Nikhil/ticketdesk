import urllib.parse
import boto3

s3 = boto3.client('s3')

def handler(event, context):
    print("S3 Event received:", event)
    for record in event.get('Records', []):
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])
        
        # Avoid infinite loop
        if key.startswith('thumbnails/'):
            print(f"Skipping thumbnail key: {key}")
            continue
            
        print(f"Processing image {key} from bucket {bucket}")
        thumbnail_key = f"thumbnails/{key}"
        try:
            s3.put_object(
                Bucket=bucket,
                Key=thumbnail_key,
                Body=f"Mock thumbnail for {key}".encode('utf-8'),
                ContentType='text/plain'
            )
            print(f"Successfully generated thumbnail: {thumbnail_key}")
        except Exception as e:
            print(f"Error generating thumbnail for {key}: {str(e)}")
            
    return {
        'statusCode': 200,
        'body': 'Thumbnail generation complete'
    }
